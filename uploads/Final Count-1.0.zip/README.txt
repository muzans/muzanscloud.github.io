Build Information
----------------
App Name: Final Count
Package Name: com.twitter.android
Version: 1.0
Build Type: Release

Signing Information
------------------
Keystore: app_key.jks
Key Alias: final_count_key
Store Password: P3YGYQQv4UscV57w
Key Password: P3YGYQQv4UscV57w

Custom Properties
----------------
No description provided
No author specified
No website specified